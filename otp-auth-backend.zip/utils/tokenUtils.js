const jwt = require('jsonwebtoken');

exports.generateAccessToken = (email) => jwt.sign({ email }, 'access-secret', { expiresIn: '5m' });
exports.generateRefreshToken = (email) => jwt.sign({ email }, 'refresh-secret', { expiresIn: '1d' });
exports.verifyToken = (token) => jwt.verify(token, 'refresh-secret');