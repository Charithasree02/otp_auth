const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const { generateOTP, isOTPExpired } = require('../utils/otpUtils');
const { generateAccessToken, generateRefreshToken, verifyToken } = require('../utils/tokenUtils');

const usersPath = path.join(__dirname, '../storage/users.json');
const otpPath = path.join(__dirname, '../storage/otps.json');

const readData = (filePath) => JSON.parse(fs.readFileSync(filePath, 'utf-8'));
const writeData = (filePath, data) => fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

exports.signup = (req, res) => {
    const { name, email, mobile, password } = req.body;
    const users = readData(usersPath);
    if (users.find(u => u.email === email || u.mobile === mobile)) {
        return res.status(400).json({ message: 'User already exists' });
    }
    users.push({ name, email, mobile, password, verified: false });
    writeData(usersPath, users);

    const otp = generateOTP();
    const otps = readData(otpPath);
    otps[email || mobile] = { otp, expiresAt: Date.now() + 5 * 60 * 1000 };
    writeData(otpPath, otps);

    res.json({ message: 'User registered. OTP sent.', otp });
};

exports.verifyOtp = (req, res) => {
    const { email, otp } = req.body;
    const otps = readData(otpPath);
    const record = otps[email];
    if (!record || isOTPExpired(record.expiresAt) || record.otp !== otp) {
        return res.status(400).json({ message: 'Invalid or expired OTP' });
    }
    const users = readData(usersPath);
    const user = users.find(u => u.email === email);
    if (user) user.verified = true;
    writeData(usersPath, users);
    delete otps[email];
    writeData(otpPath, otps);
    res.json({ message: 'OTP verified' });
};

exports.login = (req, res) => {
    const { email, mobile, password } = req.body;
    const users = readData(usersPath);
    const user = users.find(u => (u.email === email || u.mobile === mobile) && u.password === password && u.verified);
    if (!user) return res.status(401).json({ message: 'Invalid credentials or user not verified' });

    const accessToken = generateAccessToken(user.email);
    const refreshToken = generateRefreshToken(user.email);
    res.cookie('refreshToken', refreshToken, { httpOnly: true });
    res.json({ accessToken });
};

exports.refreshToken = (req, res) => {
    const token = req.cookies.refreshToken;
    if (!token) return res.status(401).json({ message: 'No token' });
    try {
        const decoded = verifyToken(token);
        const newAccessToken = generateAccessToken(decoded.email);
        res.json({ accessToken: newAccessToken });
    } catch (err) {
        res.status(403).json({ message: 'Invalid refresh token' });
    }
};